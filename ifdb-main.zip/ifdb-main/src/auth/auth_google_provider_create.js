import { GoogleAuthProvider } from "firebase/auth";

const provider = new GoogleAuthProvider();
